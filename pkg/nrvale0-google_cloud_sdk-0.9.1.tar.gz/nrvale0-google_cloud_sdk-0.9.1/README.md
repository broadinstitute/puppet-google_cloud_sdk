# puppet-google_cloud_sdk

Download and install the Google Cloud SDK tarball on Linux nodes.

## Usage
    include google_cloud_sdk

## WARNING
As of 2014.02.04, this module depends on unmerged PR to a dependency:
* camptocamp/archive (https://github.com/camptocamp/puppet-archive/pull/18)

** Please check the status of this PR before sending bug reports. ** 

## Params
* install_dir : defaults to /opt/google-cloud-sdk

## Bug reports
http://github.com/nrvale0/puppet-google_cloud_sdk/issues

## License
Apache 2.0

## Contact
Nathan Valentine : <nrvale0@gmail.com> | <Mnathan@puppetlabs.com> | @nrvale0

